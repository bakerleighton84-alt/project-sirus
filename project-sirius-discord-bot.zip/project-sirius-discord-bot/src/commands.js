import { SlashCommandBuilder, PermissionFlagsBits } from "discord.js";

export const commands = [
  new SlashCommandBuilder()
    .setName("create")
    .setDescription("Request a Project Sirius account invitation")
    .addStringOption(o => o.setName("email").setDescription("Your email address").setRequired(true).setMaxLength(254))
    .addStringOption(o => o.setName("display_name").setDescription("Your Sirius display name").setRequired(true).setMinLength(2).setMaxLength(24)),
  new SlashCommandBuilder()
    .setName("login")
    .setDescription("Request a Project Sirius login email")
    .addStringOption(o => o.setName("email").setDescription("Your account email").setRequired(true).setMaxLength(254)),
  new SlashCommandBuilder()
    .setName("server")
    .setDescription("Check Project Sirius portal status"),
  new SlashCommandBuilder()
    .setName("region")
    .setDescription("Set your account region (requires secure account linking)")
    .addStringOption(o => o.setName("region").setDescription("Choose your region").setRequired(true)
      .addChoices({ name: "Europe", value: "EU" }, { name: "North America", value: "NA" })),
  new SlashCommandBuilder()
    .setName("lookup")
    .setDescription("Admin: look up a Sirius account")
    .addStringOption(o => o.setName("account_id").setDescription("SIR- followed by 10 hexadecimal characters").setRequired(true))
    .addStringOption(o => o.setName("reason").setDescription("Reason for audited lookup").setRequired(true).setMinLength(3).setMaxLength(200))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  new SlashCommandBuilder()
    .setName("addcredits")
    .setDescription("Admin: adjust Sirius credits")
    .addStringOption(o => o.setName("account_id").setDescription("Sirius account ID").setRequired(true))
    .addIntegerOption(o => o.setName("delta").setDescription("Credits to add (positive) or remove (negative)").setRequired(true).setMinValue(-1000000).setMaxValue(1000000))
    .addStringOption(o => o.setName("reason").setDescription("Reason for audited adjustment").setRequired(true).setMinLength(3).setMaxLength(200))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  new SlashCommandBuilder()
    .setName("give")
    .setDescription("Item grants are not supported by the current Sirius locker")
    .addStringOption(o => o.setName("account_id").setDescription("Sirius account ID").setRequired(true))
    .addStringOption(o => o.setName("cosmetic_id").setDescription("Cosmetic identifier").setRequired(true).setMaxLength(100))
    .addStringOption(o => o.setName("reason").setDescription("Reason").setRequired(true).setMinLength(3).setMaxLength(200))
].map(c => c.toJSON());
