import { config } from "./config.js";

export async function callSirius(action, body = {}, userSession = null) {
  const headers = {
    "content-type": "application/json",
    authorization: `Bearer ${config.apiSecret}`
  };
  if (userSession) headers["x-sirius-user-token"] = userSession;

  const response = await fetch(`${config.apiBase}/api/public/bot/${action}`, {
    method: "POST",
    headers,
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(12_000)
  });

  let data;
  try { data = await response.json(); }
  catch { throw new Error(`Portal returned an unreadable response (HTTP ${response.status}).`); }

  if (!response.ok || data.ok === false) {
    const message = data?.error?.message || `Portal request failed (HTTP ${response.status}).`;
    throw new Error(message);
  }
  return data;
}
