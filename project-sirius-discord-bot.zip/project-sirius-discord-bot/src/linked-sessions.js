/*
 * SECURITY NOTE:
 * The current Sirius portal contract has no Discord account-linking endpoint.
 * Do not collect portal access tokens in Discord messages, slash-command options,
 * environment variables shared by all users, or plaintext files.
 *
 * When the portal adds a short-lived, single-use link flow, implement a durable
 * encrypted mapping here and verify Discord user ID + expiry + portal role.
 */
export async function getLinkedPlayerSession(_discordUserId) {
  return null;
}

export async function getLinkedAdminSession(_discordUserId) {
  return null;
}
