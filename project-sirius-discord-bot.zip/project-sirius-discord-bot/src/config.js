import "dotenv/config";

const required = ["DISCORD_TOKEN", "DISCORD_CLIENT_ID", "DISCORD_GUILD_ID", "SIRIUS_API_BASE_URL", "SIRIUS_BOT_API_SECRET"];
for (const key of required) {
  if (!process.env[key]) throw new Error(`Missing required environment variable: ${key}`);
}

const base = process.env.SIRIUS_API_BASE_URL.replace(/\/+$/, "");
export const config = {
  discordToken: process.env.DISCORD_TOKEN,
  clientId: process.env.DISCORD_CLIENT_ID,
  guildId: process.env.DISCORD_GUILD_ID,
  apiBase: base,
  apiSecret: process.env.SIRIUS_BOT_API_SECRET,
  adminRoleId: process.env.SIRIUS_DISCORD_ADMIN_ROLE_ID || null
};
