import { Client, GatewayIntentBits, Events } from "discord.js";
import { config } from "./config.js";
import { callSirius } from "./api.js";
import { getLinkedPlayerSession, getLinkedAdminSession } from "./linked-sessions.js";

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

const privateReply = (content) => ({ content, ephemeral: true });
const ACCOUNT_ID = /^SIR-[A-F0-9]{10}$/;

function requireAdminRole(interaction) {
  if (!config.adminRoleId) return false;
  return Boolean(interaction.member?.roles?.cache?.has(config.adminRoleId));
}

client.once(Events.ClientReady, ready => {
  console.log(`Project Sirius bot online as ${ready.user.tag}`);
});

client.on(Events.InteractionCreate, async interaction => {
  if (!interaction.isChatInputCommand()) return;

  try {
    await interaction.deferReply({ ephemeral: true });
    const name = interaction.commandName;

    if (name === "create") {
      const result = await callSirius("create", {
        email: interaction.options.getString("email", true),
        display_name: interaction.options.getString("display_name", true)
      });
      return interaction.editReply(privateReply(result.status === "email_requested"
        ? "If the address is eligible, an account invitation email has been requested. Check your inbox."
        : "The invitation request was submitted."));
    }

    if (name === "login") {
      const result = await callSirius("login", { email: interaction.options.getString("email", true) });
      return interaction.editReply(privateReply(result.status === "email_requested"
        ? "If an account exists for that address, a login email has been requested. Check your inbox."
        : "The login request was submitted."));
    }

    if (name === "server") {
      const result = await callSirius("server", {});
      return interaction.editReply(privateReply(
        `Portal: ${result.portal}\nDiscord bot (portal-reported): ${result.discord_bot}\nGame backend: ${result.game_backend}`
      ));
    }

    if (name === "region") {
      const token = await getLinkedPlayerSession(interaction.user.id);
      if (!token) return interaction.editReply(privateReply(
        "Secure Discord-to-Sirius account linking is not available yet. Sign in on the portal to manage your region. Never send your session token in Discord."
      ));
      const result = await callSirius("region", { region: interaction.options.getString("region", true) }, token);
      return interaction.editReply(privateReply(`Your region is now ${result.region}.`));
    }

    if (name === "lookup" || name === "addcredits") {
      if (!requireAdminRole(interaction)) {
        return interaction.editReply(privateReply("You are not authorised to use this command."));
      }
      const token = await getLinkedAdminSession(interaction.user.id);
      if (!token) return interaction.editReply(privateReply(
        "Secure admin account linking is not configured yet. The portal must issue a short-lived, verified admin link before this command can run."
      ));

      const accountId = interaction.options.getString("account_id", true).toUpperCase();
      if (!ACCOUNT_ID.test(accountId)) return interaction.editReply(privateReply("Account ID must look like SIR-0123456789."));

      if (name === "lookup") {
        const result = await callSirius("lookup", {
          account_id: accountId,
          reason: interaction.options.getString("reason", true)
        }, token);
        const a = result.account;
        return interaction.editReply(privateReply(
          `Account: ${a.account_id}\nName: ${a.display_name}\nRegion: ${a.region}\nSirius credits: ${a.sirius_credits}\nDisabled: ${a.is_disabled}`
        ));
      }

      const delta = interaction.options.getInteger("delta", true);
      if (delta === 0) return interaction.editReply(privateReply("Credit adjustment cannot be zero."));
      const result = await callSirius("addcredits", {
        account_id: accountId,
        delta,
        reason: interaction.options.getString("reason", true)
      }, token);
      return interaction.editReply(privateReply(`Credit adjustment completed. New balance: ${result.sirius_credits}`));
    }

    if (name === "give") {
      return interaction.editReply(privateReply(
        "Item grants are currently disabled: the Project Sirius API returns NOT_IMPLEMENTED because the locker has no item-ownership ledger."
      ));
    }
  } catch (error) {
    console.error("Command failed:", error);
    const message = error instanceof Error ? error.message : "Unexpected error.";
    const safe = message.length > 300 ? "The portal request failed. Please try again later." : message;
    if (interaction.deferred || interaction.replied) await interaction.editReply(privateReply(safe)).catch(() => {});
    else await interaction.reply(privateReply(safe)).catch(() => {});
  }
});

client.login(config.discordToken);
