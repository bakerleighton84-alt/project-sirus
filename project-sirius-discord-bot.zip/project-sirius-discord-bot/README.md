# Project Sirius Discord bot

Discord.js v14 slash-command scaffold using the existing Sirius public bot API contract.

## Commands

- `/create email display_name` — requests an invitation email.
- `/login email` — requests a login email.
- `/server` — reports portal status.
- `/region region` — safely reports that linking is required until the portal supports it.
- `/lookup account_id reason` — admin-only; requires secure linked admin session.
- `/addcredits account_id delta reason` — admin-only; requires secure linked admin session.
- `/give ...` — reports that the portal does not implement item grants.

## Setup

1. Use Node.js 20 or newer.
2. Copy `.env.example` to `.env` and fill in the Discord application values, portal URL, and bot API secret.
3. In the Discord Developer Portal, create a bot and invite it with `bot` and `applications.commands` scopes.
4. Run `npm install`.
5. Run `npm run register` once to register guild slash commands.
6. Run `npm start`.

## Required environment variables

- `DISCORD_TOKEN`
- `DISCORD_CLIENT_ID`
- `DISCORD_GUILD_ID`
- `SIRIUS_API_BASE_URL` — portal origin only, e.g. `https://your-portal.example.com`
- `SIRIUS_BOT_API_SECRET` — must match the portal's secret
- `SIRIUS_DISCORD_ADMIN_ROLE_ID` — optional role gate for admin commands

## Important integration gap

The inspected Project Sirius portal currently supports the API actions but does **not** implement secure Discord-to-portal account linking. `/region`, `/lookup`, and `/addcredits` require a portal user/admin session token in `x-sirius-user-token`. This bot intentionally does not collect tokens in Discord, put one shared token in `.env`, or pretend that Discord role membership proves portal admin status.

To enable those commands, the portal needs a secure linking flow that:
- issues a short-lived, single-use code while the user is signed into the portal;
- binds that code to the initiating Discord user ID;
- verifies and consumes it server-side;
- stores the resulting session mapping securely and expires/revokes it;
- confirms admin privileges from the portal on every admin request.

The current API's `/give` action returns HTTP 501 and cannot grant cosmetics until the portal adds item ownership support.

## Security

- All command replies are ephemeral.
- Email requests are sent to the email owner; login links are never posted in Discord.
- Admin commands are gated by an optional Discord role and still rely on portal-side authorization.
- Never commit `.env` or share the bot API secret.
